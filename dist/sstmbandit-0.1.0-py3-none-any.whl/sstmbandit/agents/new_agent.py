from . import algorithms
import numpy as np
from .ucb_agents import AbstractAgent


class ArmFunc:
    def __init__(self) -> None:
        self.grads = None

    @property
    def L(self):
        return 1.0

    def generate_grad(self, x, n=1):
        assert self.grads is not None
        for i in range(n):
            yield x - self.grads[i]


class Arm:
    def __init__(self, d: int = 1) -> None:
        K = 10_000
        f = ArmFunc()
        smom = algorithms.SMoM(n=2, m=2, d=d, theta=0.001)
        x0 = np.zeros(shape=(d,))
        alpha0 = 0.0
        R = 10
        L = f.L  # * R
        delta = 1 / K**2
        A = np.log(4 * (K + 1) / delta)
        a = (d) ** 0.5
        self.sstm = algorithms.ClippedSSTM(
            x0=x0, func=f, smom=smom, a=a, alpha0=alpha0, L=L, R=R, delta=delta
        )
        self.sstm.lambd_update_coeff = R / np.log(4 * (K + 1) / delta)

    @property
    def mean(self):
        return self.sstm.y

    def pull(self):
        self.sstm.step()


class NewAgent(AbstractAgent):
    def __init__(self, n_actions: int, coeff: float = 1.0) -> None:
        super().__init__(n_actions=n_actions, history_len=0)
        n, m = 2, 2
        self.pulls_per_iter = (2 * m + 1) * n
        K = 10_000
        self.delta = 1 / K**2
        self._total_calls = 0  # это не пуллы, а выбор ручки

        self.arms = [Arm() for i in range(n_actions)]
        self.coeff = coeff

        self.selected = False
        self.selected_arm = None
        self.selected_count = 0
        self.selected_rewards = []

    def reset(self):
        self.__init__(self.n_actions, self.coeff)

    def _select(self, action):
        self.selected = True
        self.selected_arm = action
        self.selected_rewards = []

    def _un_select(self):
        self.selected = False
        self.selected_arm = None
        self.selected_rewards = []

    def get_action(self):
        if self.selected:
            return self.selected_arm

        t = self._total_calls
        if t < self.n_actions:
            self._select(t)
            return t
        means = np.array([self.arms[i].mean for i in range(self.n_actions)]).reshape(-1)

        means = means + (
            self.coeff * np.log(t**2) / np.sqrt(self._history_pull)
        ).reshape(-1)
        arm = np.argmax(means)
        self._select(arm)
        return arm

    def _update(self):
        arm = self.arms[self.selected_arm]
        arm.sstm.func.grads = self.selected_rewards
        arm.pull()

    def update(self, action, reward):
        self._total_pulls += 1
        self._history_pull[action] += 1
        self._rewards[action].append(reward)
        if self.selected:
            self.selected_rewards.append(reward)
            if len(self.selected_rewards) >= self.pulls_per_iter:
                self._update()
                self._un_select()
                self._total_calls += 1
