from typing import Any

import numpy as np
import numpy.typing as npt


class SMoM:
    def __init__(self, n=2, m=2, d=1, *, theta) -> None:
        self.n = n
        self.m = m
        self.d = d
        self.theta = theta

    def __call__(self, **kwargs) -> Any:
        """
        kwargs shold contain

        sample_list -- list of samples

        or

        generator -- generator of elements
        """
        if "sample_list" in kwargs:
            sample_list = kwargs["sample_list"]
        elif "generator" in kwargs:
            generator = kwargs["generator"]
            generator = generator((2 * self.m + 1) * self.n)
            sample_list = list(generator)
        else:
            raise ValueError(
                f"kwargs should contain one of ['sample_list', 'generator'],\
                    instead get {kwargs.keys()=}"
            )
        assert len(sample_list) == (2 * self.m + 1) * self.n
        means = [
            np.mean(sample_list[j * self.n : (j + 1) * self.n], axis=0)
            + self.theta
            * np.random.multivariate_normal(
                mean=np.zeros(shape=(self.d)), cov=np.eye(self.d)
            )
            for j in range(2 * self.m + 1)
        ]
        means = np.stack(means, axis=0)
        medians = np.median(means, axis=0)

        # sample_list_means = np.array(sample_list).mean(axis=0)
        # if not np.allclose(medians, sample_list_means):
        #     print(sample_list_means, medians)
        #     print(means)
        #     print(sample_list)
        #     raise ValueError()
        return medians


class Func:
    def __init__(self, d) -> None:
        from scipy.stats import ortho_group

        self.d = d
        U = ortho_group.rvs(dim=d)
        diag = np.diag(np.random.rand(self.d) * 2 + 2)
        mu = np.random.rand(d)
        self.mu = mu
        self.A = U.T @ diag @ U

    def _noise(self):
        return np.random.standard_cauchy(size=self.d)

    @property
    def L(self):
        return np.max(np.linalg.eigvals(self.A))

    def generate_grad(self, x, n=1):
        tmp = self.A @ (x - self.mu)
        for _ in range(n):
            yield tmp + self._noise()

    def __call__(self, x) -> float:
        return 0.5 * (x - self.mu).T @ self.A @ (x - self.mu)


class ClippedSSTM:
    def __init__(
        self,
        *,
        x0: npt.ArrayLike,
        func: Func,
        smom: SMoM,
        a: float,
        alpha0: float,
        L: float,
        R: float,
        delta: float,
    ) -> None:
        self.func = func
        self.smom = smom
        self.x = x0.copy()
        self.y = x0.copy()
        self.z = x0.copy()
        self.a = a
        self.L = L
        self.R = R
        self.delta = delta

        self.k = 0
        self.alpha_prev = alpha0
        self.A_prev = alpha0

        self.alpha_next = None
        self.A_next = None
        self.lambd_next = None

    @staticmethod
    def clip(vect: npt.ArrayLike, lambd):
        norm = np.linalg.norm(
            vect,
        )
        if norm == 0:
            return np.zeros_like(vect, dtype=float)
        else:
            return min(1, lambd / norm) * vect

    def param_next_update(self):
        self.alpha_next = (self.k + 2) / (2 * self.a * self.L)
        self.A_next = self.A_prev + self.alpha_next
        self.lambd_next = self.lambd_update_coeff / self.alpha_next

    def param_prev_set(self):
        self.alpha_prev = self.alpha_next
        self.A_prev = self.A_next
        self.lambd_prev = self.lambd_next

    def step(self):
        self.param_next_update()
        self.x = (self.A_prev * self.y + self.alpha_next * self.z) / self.A_next
        generator = lambda num: self.func.generate_grad(self.x, num)
        x_meaned = self.smom(generator=generator)
        grad_clipped = self.clip(x_meaned, self.lambd_next)
        self.z = self.z - self.alpha_next * grad_clipped
        self.y = (self.A_prev * self.y + self.alpha_next * self.z) / self.A_next
        self.param_prev_set()
        self.k += 1

    def run(self, K: int, lambd_update_coeff: float | None = None, verbose=False):
        if lambd_update_coeff is None:
            self.lambd_update_coeff = self.R / np.log(4 * (K + 1) / self.delta)
        else:
            self.lambd_update_coeff = lambd_update_coeff

        if verbose:
            x_s = []
            rez = []
        for _ in range(K):
            self.step()
            if verbose:
                x_s.append(self.y)
                rez.append(self.func(self.y))
        if verbose:
            return rez, x_s
        else:
            return


# class RestartsClippedSSTM:
#     def __init__(self, **kwargs) -> None:
#         self.kwargs = kwargs
#         self.x = kwargs['x0']
#         self.func = self.kwargs['func']

#     def run(self, iterations, verbose = False):
#         rez = []
#         for t in range(iterations):
#             R_t = self.R / (2 ** ((t)/ 2.))
#             R_t_m1 = self.R / (2 ** ((t - 1)/ 2.))
#             eps_t = 0
#             K_t = max( )
#             lambd_update_coeff = R_t /(30 *
# np.log(4 * K_t * iterations / self.delta))
#             a_t = max (...)
#             self.kwargs['a'] = a_t
#             self.kwargs['x0'] = self.x
#             sstm_t = ClippedSSTM(**self.kwargs)
#             sstm_t.run(K_t, lambd_update_coeff, verbose=verbose)
#             self.x = sstm_t.y
