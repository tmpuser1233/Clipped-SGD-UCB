import numpy as np
from abc import abstractmethod, ABC
import typing as tp
class AbstractEnv(ABC):
    """
    Abstract class for environment.
    Custum environment should contain pull method to pull one arm

    For testing optimmal_reward and action_reward methods should be implemented.
    See examples.
    """
    def __init__(self, n_actions: int) -> None:
        super().__init__()
        self.n_actions = n_actions
    
    @abstractmethod
    def pull(self, action: tp.Any) -> int|float:
        raise NotImplementedError
    
    def optimal_reward(self) -> int|float:
        """
        returns expected reward of the best arm
        """
        raise NotImplementedError
    def action_reward(self, action: tp.Any) -> int|float:
        """
        returns expected reward of given action
        """
        raise NotImplementedError


class CauchyDistributionEnv(AbstractEnv):
    """
    Environment with arms with noise distributed as Cauchy distribution
    
    https://en.wikipedia.org/wiki/Cauchy_distribution
    
    parameters:
        reward_arr: tp.Iterable[float]
        array of parameters

        gamma: float
        distribution parameter
    """
    def __init__(self, n_actions: int =5, reward_arr: tp.Iterable[float] =np.arange(5), gamma: float=1.0) -> None:
        assert len(reward_arr) == n_actions
        super().__init__(n_actions)
        self.reward_arr = reward_arr
        self.n_actions = n_actions
        self.gamma = gamma

    def _sample_noise(self)-> float:
        unif = np.random.rand()
        rez = self.gamma * np.tan(np.pi * (unif - 0.5))
        return rez

    def pull(self, action: int)->float:
        rez = self.reward_arr[action] + self._sample_noise()
        return rez

    def optimal_reward(self)-> float:
        return np.max(self.reward_arr)

    def action_reward(self, action: int) -> float:
        return self.reward_arr[action]


class FrechetDistribution(AbstractEnv):
    """
    Environment with arms with noise distributed as Fréchet distribution
    
    https://en.wikipedia.org/wiki/Fréchet_distribution
    
    parameters:
        reward_arr: tp.Iterable[float]
        array of parameters

        alpha: float
        distribution parameter. Noise will has standardized moment k for k < alpha
    """
    def __init__(self, n_actions: int =5, reward_arr: tp.Iterable[float] =np.arange(5), alpha: float = 0.5) -> None:
        assert alpha > 0
        assert len(reward_arr) == n_actions
        self.alpha = alpha
        self.reward_arr = reward_arr
        self.n_actions = n_actions

    def reset(self):
        pass

    def _sample_noise(self) -> float:
        unif = np.random.rand()
        noise = (-np.log(unif)) ** (-1.0 / self.alpha)
        return noise
    
    def pull(self, action: int)->float:
        rez = self.reward_arr[action] + self._sample_noise()
        return rez

    def optimal_reward(self)-> float:
        return np.max(self.reward_arr)

    def action_reward(self, action: int) -> float:
        return self.reward_arr[action]